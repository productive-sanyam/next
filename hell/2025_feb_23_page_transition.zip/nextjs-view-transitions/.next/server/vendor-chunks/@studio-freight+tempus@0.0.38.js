"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/@studio-freight+tempus@0.0.38";
exports.ids = ["vendor-chunks/@studio-freight+tempus@0.0.38"];
exports.modules = {

/***/ "(ssr)/./node_modules/.pnpm/@studio-freight+tempus@0.0.38/node_modules/@studio-freight/tempus/dist/tempus.modern.mjs":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/.pnpm/@studio-freight+tempus@0.0.38/node_modules/@studio-freight/tempus/dist/tempus.modern.mjs ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ a)\n/* harmony export */ });\nvar a=\"undefined\"!=typeof window&&new class{constructor(){this.raf=a=>{requestAnimationFrame(this.raf);const t=a-this.now;this.now=a;for(let s=0;s<this.callbacks.length;s++)this.callbacks[s].callback(a,t)},this.callbacks=[],this.now=performance.now(),requestAnimationFrame(this.raf)}add(a,t=0){return this.callbacks.push({callback:a,priority:t}),this.callbacks.sort((a,t)=>a.priority-t.priority),()=>this.remove(a)}remove(a){this.callbacks=this.callbacks.filter(({callback:t})=>a!==t)}};\n//# sourceMappingURL=tempus.modern.mjs.map\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9ub2RlX21vZHVsZXMvLnBucG0vQHN0dWRpby1mcmVpZ2h0K3RlbXB1c0AwLjAuMzgvbm9kZV9tb2R1bGVzL0BzdHVkaW8tZnJlaWdodC90ZW1wdXMvZGlzdC90ZW1wdXMubW9kZXJuLm1qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsNENBQTRDLGNBQWMsYUFBYSxnQ0FBZ0MsbUJBQW1CLFdBQVcsWUFBWSx3QkFBd0Isb0NBQW9DLDhFQUE4RSxXQUFXLDRCQUE0QixzQkFBc0IsdUVBQXVFLFVBQVUsdUNBQXVDLFdBQVcsWUFBaUM7QUFDNWYiLCJzb3VyY2VzIjpbIi9Vc2Vycy9oYXJybmlzaC9EZXNrdG9wL25leHRqcy12aWV3LXRyYW5zaXRpb25zL25vZGVfbW9kdWxlcy8ucG5wbS9Ac3R1ZGlvLWZyZWlnaHQrdGVtcHVzQDAuMC4zOC9ub2RlX21vZHVsZXMvQHN0dWRpby1mcmVpZ2h0L3RlbXB1cy9kaXN0L3RlbXB1cy5tb2Rlcm4ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBhPVwidW5kZWZpbmVkXCIhPXR5cGVvZiB3aW5kb3cmJm5ldyBjbGFzc3tjb25zdHJ1Y3Rvcigpe3RoaXMucmFmPWE9PntyZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGhpcy5yYWYpO2NvbnN0IHQ9YS10aGlzLm5vdzt0aGlzLm5vdz1hO2ZvcihsZXQgcz0wO3M8dGhpcy5jYWxsYmFja3MubGVuZ3RoO3MrKyl0aGlzLmNhbGxiYWNrc1tzXS5jYWxsYmFjayhhLHQpfSx0aGlzLmNhbGxiYWNrcz1bXSx0aGlzLm5vdz1wZXJmb3JtYW5jZS5ub3coKSxyZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGhpcy5yYWYpfWFkZChhLHQ9MCl7cmV0dXJuIHRoaXMuY2FsbGJhY2tzLnB1c2goe2NhbGxiYWNrOmEscHJpb3JpdHk6dH0pLHRoaXMuY2FsbGJhY2tzLnNvcnQoKGEsdCk9PmEucHJpb3JpdHktdC5wcmlvcml0eSksKCk9PnRoaXMucmVtb3ZlKGEpfXJlbW92ZShhKXt0aGlzLmNhbGxiYWNrcz10aGlzLmNhbGxiYWNrcy5maWx0ZXIoKHtjYWxsYmFjazp0fSk9PmEhPT10KX19O2V4cG9ydHthIGFzIGRlZmF1bHR9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dGVtcHVzLm1vZGVybi5tanMubWFwXG4iXSwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMF0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(ssr)/./node_modules/.pnpm/@studio-freight+tempus@0.0.38/node_modules/@studio-freight/tempus/dist/tempus.modern.mjs\n");

/***/ })

};
;