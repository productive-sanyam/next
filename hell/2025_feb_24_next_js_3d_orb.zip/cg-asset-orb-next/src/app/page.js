import Orb from "./Orb";

export default function Home() {
  return (
    <>
      <nav>
        <h1>Orb</h1>
      </nav>
      <Orb />
      <footer>
        <p>[ Archive beyond reality ]</p>
      </footer>
    </>
  );
}
